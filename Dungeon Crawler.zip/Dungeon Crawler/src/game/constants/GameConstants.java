package game.constants;

public interface GameConstants {
	public final static int FRAME_WIDTH = 320;
	public final static int FRAME_HEIGHT = 320;
}
