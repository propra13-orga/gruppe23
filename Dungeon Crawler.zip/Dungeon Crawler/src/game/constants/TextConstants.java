package game.constants;

public interface TextConstants {
	public final static String TITLE = "Dungeon Crawler";
}
